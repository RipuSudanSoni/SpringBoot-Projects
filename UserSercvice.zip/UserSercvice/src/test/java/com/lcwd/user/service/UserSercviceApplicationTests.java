package com.lcwd.user.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSercviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
